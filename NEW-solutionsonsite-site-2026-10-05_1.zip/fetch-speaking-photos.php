<?php
/**
 * SolutionsOnSite — one-off import of Sue's 8 speaking photos into /images/
 *
 * Copies each photo from Sue's Google Drive as a web-sized JPEG (max 1200px wide,
 * quality 82), so the site no longer depends on Google for any images.
 * Usage: upload to public_html, open https://www.solutionsonsite.uk/fetch-speaking-photos.php
 * once in a browser. It deletes itself when all 8 are saved.
 */
@set_time_limit(300);
@ini_set('memory_limit', '256M');
header('Content-Type: text/plain; charset=utf-8');

$photos = array(
    'speaking-01.jpg' => '1pqQbGZAZXvkWiZ5o624RIS1DJgDlgPkU', // _DSC_2613-Enhanced-NR.jpg
    'speaking-02.jpg' => '1NXu-NtT_C9cXSUK1SvUa14_8gVp3yeS6', // DSC_2620-Enhanced-NR.jpg
    'speaking-03.jpg' => '1_aKKjP3KjBMlj8Vn0KIj_q-rDhirO9hd', // IMG_20240926_141624.jpg
    'speaking-04.jpg' => '13d7TJYRRxtaLHfnWIjnmjzAOeU8KjbZk', // Image.jpg (5.4 MB original)
    'speaking-05.jpg' => '10yxbYp5QssreOvG_NAvmGyc5Jfia3pVB', // IMG_5099.jpg (9.1 MB original)
    'speaking-06.jpg' => '1kzSI50DGmVdEvhVDdwg9RuENwMSCccK2', // IMG_5101 - RESIZED.jpg (4.6 MB original)
    'speaking-07.jpg' => '1wrDWO-DFBCrlDN4lPF4NrzM0thZSyFVh', // P3182714.JPG (6.5 MB original)
    'speaking-08.jpg' => '19fNCXrQ7wBN9BtG0urhwBpoPgilatLMw', // P3182713.JPG (6.3 MB original)
);
$maxW = 1200;
$dir  = __DIR__ . '/images';

if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
    exit("Cannot create $dir\n");
}

function fetch_url($url) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 90,
            CURLOPT_USERAGENT      => 'Mozilla/5.0 (SolutionsOnSite image import)',
            CURLOPT_HTTPHEADER     => array('Accept: image/jpeg,image/*;q=0.8'),
        ));
        $data = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ($code === 200 && $data !== false) ? $data : false;
    }
    $ctx = stream_context_create(array('http' => array(
        'timeout' => 90,
        'header'  => "User-Agent: Mozilla/5.0 (SolutionsOnSite image import)\r\nAccept: image/jpeg,image/*;q=0.8\r\n",
    )));
    return @file_get_contents($url, false, $ctx);
}

$saved = 0;
foreach ($photos as $name => $id) {
    $data = false;
    // Google's image server: =w1200 asks for a resized, orientation-corrected copy
    foreach (array("https://lh3.googleusercontent.com/d/$id=w$maxW", "https://lh3.googleusercontent.com/d/$id") as $url) {
        $data = fetch_url($url);
        if ($data !== false && @getimagesizefromstring($data)) { break; }
        $data = false;
    }
    if ($data === false) {
        echo "FAILED  $name  (Drive file $id - check it is still shared 'Anyone with the link')\n";
        continue;
    }

    // Normalise: JPEG, max $maxW wide, quality 82 (needs PHP GD; otherwise saved as served)
    if (function_exists('imagecreatefromstring')) {
        $img = @imagecreatefromstring($data);
        if ($img) {
            $w = imagesx($img);
            $h = imagesy($img);
            if ($w > $maxW) {
                $nh = (int) round($h * $maxW / $w);
                $resized = imagecreatetruecolor($maxW, $nh);
                imagecopyresampled($resized, $img, 0, 0, 0, 0, $maxW, $nh, $w, $h);
                imagedestroy($img);
                $img = $resized;
            }
            imageinterlace($img, true); // progressive JPEG
            ob_start();
            imagejpeg($img, null, 82);
            $data = ob_get_clean();
            imagedestroy($img);
        }
    }

    if (file_put_contents("$dir/$name", $data) === false) {
        echo "FAILED  $name  (could not write to /images - check folder permissions)\n";
        continue;
    }
    $info = getimagesizefromstring($data);
    printf("OK      %s  %dx%d  %d KB\n", $name, $info[0], $info[1], round(strlen($data) / 1024));
    $saved++;
}

echo "\n$saved of " . count($photos) . " photos saved to /images/\n";
if ($saved === count($photos)) {
    echo @unlink(__FILE__)
        ? "Done. This script has deleted itself.\n"
        : "Done. Now delete fetch-speaking-photos.php from public_html.\n";
} else {
    echo "Reload this page to retry the failures, then delete the script.\n";
}
