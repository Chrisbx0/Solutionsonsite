/* SolutionsOnSite — site.js (no dependencies) */
(function () {
  "use strict";

  /* Mobile menu */
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.getElementById("site-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!open));
      nav.classList.toggle("is-open", !open);
    });
  }

  /* Services submenu */
  var subToggles = document.querySelectorAll(".sub-toggle");
  subToggles.forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      e.stopPropagation();
      var open = btn.getAttribute("aria-expanded") === "true";
      btn.setAttribute("aria-expanded", String(!open));
    });
  });
  function closeSubs() {
    subToggles.forEach(function (b) { b.setAttribute("aria-expanded", "false"); });
  }
  document.addEventListener("click", function (e) {
    if (!e.target.closest(".has-sub")) closeSubs();
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      closeSubs();
      if (toggle && nav && nav.classList.contains("is-open")) {
        toggle.setAttribute("aria-expanded", "false");
        nav.classList.remove("is-open");
        toggle.focus();
      }
    }
  });

  /* Contact form — posts to the live site's Formspree endpoint */
  var form = document.querySelector("form.contact-form");
  if (form) {
    var status = form.querySelector(".form-status");
    var button = form.querySelector("button[type=submit]");
    var labels = { name: "Enter your name.", email: "Enter an email address like name@company.co.uk.", message: "Enter a message." };

    function fieldError(name, msg) {
      var input = form.querySelector("[name=" + name + "]");
      if (!input) return;
      input.setAttribute("aria-invalid", "true");
      var p = document.createElement("p");
      p.className = "field-error";
      p.id = name + "-error";
      p.textContent = msg;
      input.setAttribute("aria-describedby", p.id);
      input.insertAdjacentElement("afterend", p);
    }

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      form.querySelectorAll(".field-error").forEach(function (el) { el.remove(); });
      form.querySelectorAll("[aria-invalid]").forEach(function (el) { el.removeAttribute("aria-invalid"); });
      status.hidden = true;

      /* check required fields before sending */
      var bad = false;
      ["name", "email", "message"].forEach(function (n) {
        var el = form.querySelector("[name=" + n + "]");
        var v = (el.value || "").trim();
        if (!v || (n === "email" && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v))) { fieldError(n, labels[n]); bad = true; }
      });
      if (bad) {
        status.className = "form-status err";
        status.textContent = "Check the highlighted fields and try again.";
        status.hidden = false;
        form.querySelector("[aria-invalid=true]").focus();
        return;
      }

      button.disabled = true;
      button.textContent = "Sending…";
      fetch(form.action, { method: "POST", body: new FormData(form), headers: { "Accept": "application/json" } })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (d) { d._ok = r.ok; return d; }); })
        .then(function (data) {
          if (data._ok && data.ok !== false) {
            form.reset();
            status.className = "form-status ok";
            status.textContent = "Message sent. Sue will get back to you within 24 hours.";
          } else if (data.errors && data.errors.length) {
            data.errors.forEach(function (er) { if (er.field) fieldError(er.field, labels[er.field] || er.message); });
            throw new Error("validation");
          } else {
            throw new Error("send failed");
          }
        })
        .catch(function () {
          status.className = "form-status err";
          status.innerHTML = 'The message didn\'t send. Email <a href="mailto:sue@solutionsonsite.uk">sue@solutionsonsite.uk</a> or call 07834 173050 instead.';
        })
        .finally(function () {
          status.hidden = false;
          button.disabled = false;
          button.textContent = "Send message";
        });
    });
  }
})();
